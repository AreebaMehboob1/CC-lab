#include <stdio.h>
int main()
{	
	/* Hello,
	This is
	a sample
	multi-line 
	comment*/
	/* This is a basic program to
	check the proper execution
	of Lexical Scanner*/
	struct node{
	int a;
	char name;
	};

	/*This is a another 
	multi-line comment*/

	//Following are basic constants and identifiers
	float fl = 5.01;
	char l1 = 'a', l2 ='1';
	int _a=0,b=0,c=5;
	int arr[50];
	char *ptr;
	scanf("%d %d",&a,&b);
	int sum=0;
	sum=a+b;
	printf("\n Sum : %d \n",sum);

	//Enter Name
	char *name = "Hello";
	char *name = "John Doe";

	//End the main function
	return 1;
}
void abc()
{
	printf("\nTest function ");
	printf("\nInside abc() function\n");
}