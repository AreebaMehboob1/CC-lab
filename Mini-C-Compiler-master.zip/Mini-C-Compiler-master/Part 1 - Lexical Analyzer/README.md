# Lexical Analyser

## Execution

### Windows
```
cd Code
lex LexicalScanner.l
gcc lex.yy.c
a.exe <input c-filename>
```

#### Linux/Ubuntu
```
cd Code
lex LexicalScanner.l
gcc lex.yy.c
./a.out <input c-filename>
```