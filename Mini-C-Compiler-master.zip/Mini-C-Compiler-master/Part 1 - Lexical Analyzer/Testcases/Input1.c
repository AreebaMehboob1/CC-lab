#include<stdio.h>

int main(){
	int a;
	char str[24] = "Hi!";
	for(a = 0; a<4; a++){
		if(a == 3){
			str = "Bye!;
		};
	}
	return 0;
}