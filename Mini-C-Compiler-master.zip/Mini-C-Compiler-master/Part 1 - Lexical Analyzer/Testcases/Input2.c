#include<stdio.h>

int main(){
	//This is a simple single comment

	/* This is a
	multi-line comment */

	char c = 'C';

	/*
	This is 
	a 
	/* nested
	comment*/
	*/

	int a;
	return 0;
}