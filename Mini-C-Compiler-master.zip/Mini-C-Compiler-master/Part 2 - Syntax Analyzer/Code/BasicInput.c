#include<stdio.h>

void lng(char ma, int t){
	int y=9;
}
int main()
{
	int a = 5;
	int h[5];
	//Hello
	char* c = 'u';
	char* ii[4+a];
	/* Multi
	line comment
	*/
	while(a>0)
	{
		/*
		Nested
		/* comment */ 
		/*
		dd
		*/
		*/
		printf("%d",a);
		a--;
		int* arr[4+a];
		while(b>0)
		{
			printf("%d", a*b);
			b--;
		}
	}
	return 0;
}
