#include stdio.h>   

int main()
{
    //Example for invalid preprocessor directive
    printf("Hello");
    return 0;
}
