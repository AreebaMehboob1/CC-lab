#include <stdio.h>

void main(){
	/*Program to show 
	working program for 
	operators
	*/ 
	int a=2,b=1,c,d;
	c = a+b;    // Addition
	d = a%b;    // Reminder
	c = c&&d;    // AND
	a = a||b;    // OR
	b = a^b;	// Bitwise XOR
}
