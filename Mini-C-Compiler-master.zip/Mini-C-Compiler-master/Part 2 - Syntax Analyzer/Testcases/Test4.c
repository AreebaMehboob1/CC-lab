#include<stdio.h>

struct node [           //Structure Declaration

   int a;
   char b;
};

int main()
{
	struct node A;
	A.a = 25;
	A.b = 'c';
        return 0;
}
