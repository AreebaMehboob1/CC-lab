#include<stdio.h>
#define NUM 5  

int main()
{
char A[] = "Happy Birthday";
unsigned a = 1;
int c=NUM/a;
return 0;
}
