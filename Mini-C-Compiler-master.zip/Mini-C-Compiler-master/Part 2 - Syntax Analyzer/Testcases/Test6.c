#include<stdio.h>
int main()
{
 /*                            //Comment not closed
 int a = 1, b=0;
 if(a >= 1 && b>=10)
   a++;
  else
   b--;
}
