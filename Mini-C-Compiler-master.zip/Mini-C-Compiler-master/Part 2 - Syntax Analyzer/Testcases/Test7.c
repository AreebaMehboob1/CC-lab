#include<stdio.h>
void main(){
	/* Example for string quotes not closed*/
	int a=1;
	char b[100] = "Help me;
	int c[10]={0};

}
