#include <stdio.h>
 
int main () {

   /* local variable definition */
   int a = 10;

   /* while loop execution */
   while(a<4{
      printf("a=%d\n",a);
   }
    //Testcase with while loop
 
   return 0;
}
