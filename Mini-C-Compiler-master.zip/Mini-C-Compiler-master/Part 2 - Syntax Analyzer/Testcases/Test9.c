// Invalid identifier

#include<stdio.h>

int main() {
    char 9ident;
    9ident = 'c';
}
