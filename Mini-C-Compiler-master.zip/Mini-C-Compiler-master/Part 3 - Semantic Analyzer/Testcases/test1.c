// infinite loop, redefinition of k inside while
#include <stdio.h>

int b=10;

int main()
{
	int k=5;
	long int z;
	while(1)
	{
		int k;
		while(1)
		{
			while(1)
			{
				int s;
			}
		}
	}
	return 0;
}