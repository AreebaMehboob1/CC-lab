// Working code
#include <stdio.h>

int main()
{
	int a =4;
	float p=2.3;
  unsigned int x;
  long int y;
  short int z;
  return 0;
}