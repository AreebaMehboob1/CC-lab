//  Working testcase
#include <stdio.h>

int trial()
{
	int a;

	return 1;
}

int main()
{
	int k=5;
	long int z;
	while(1)
	{
		int b=5;
		while(1)
		{
			int c;
		}
	}
}