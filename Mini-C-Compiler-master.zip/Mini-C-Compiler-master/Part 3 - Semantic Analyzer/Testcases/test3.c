//Initialisation without declaration
#include <stdio.h>

int main()
{
	int a =4;
	b=9;
	a=10;
	return 0;
}
