// Working code
#include <stdio.h>

int main()
{
	int a =4;
	int b=9;
	int a=10;
	return 0;
}