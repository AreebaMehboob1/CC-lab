// Undeclared variable assigned
#include <stdio.h>

int main()
{
	int a =4;
	{
		int c=10;
	}
	c=8;
	a=9;
	return 0;
}