// Working code
#include <stdio.h>

int main()
{
	int a;
  int b =4.2;
	return 0;
}