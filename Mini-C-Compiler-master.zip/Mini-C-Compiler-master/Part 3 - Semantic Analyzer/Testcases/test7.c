// Function name an identifier
#include <stdio.h>

int main()
{
	int a =5;
	return 0;
}
void Scanf()
{
	return;
}