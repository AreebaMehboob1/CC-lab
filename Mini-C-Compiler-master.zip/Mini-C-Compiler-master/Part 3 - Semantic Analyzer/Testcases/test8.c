// Working code
#include <stdio.h>
int trial(int b, float a)
{
return 3.14;
}

int main()
{
	int k=5;
	trial(k,3.4);
	long int z;
	return 0;
}