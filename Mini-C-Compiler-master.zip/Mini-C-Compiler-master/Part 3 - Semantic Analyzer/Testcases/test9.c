// Infinite loop
#include <stdio.h>

int k;

int main()
{
	int b;
	b=10;
	while(1)
	{
		int k;
		while(1)
		{
			int b=4;
		}
	}
	return 0;
}