#include<stdio.h>

int number = 0;

int fun(int a, int b, char c)
{
  return 2 ;
}

int main()
{

  int x = 1;

  int y;
  int z;
  int a,b;

  if(x<0)
  {
    int y;

    int z=1;

    {
      int w =1;
    }
  }
  char c='a';
  for(x=2;x<y;x++)
  {
    break;
  }
  return 3;

}
