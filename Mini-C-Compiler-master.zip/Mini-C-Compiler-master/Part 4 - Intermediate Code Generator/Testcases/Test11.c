// Function returning value for void
#include<stdio.h>

void square(int num)
{
    return num*num;
}

void main()
{
    int i,n;
    square(i);
    
}
