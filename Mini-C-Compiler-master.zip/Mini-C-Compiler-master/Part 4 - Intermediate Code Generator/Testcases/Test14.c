// Valid array declaration
#include <stdio.h>

int main(){
	int g[9];
	g[0] = 9;
	return 0;
}
