// Invalid array declaration
#include <stdio.h>

int main(){
	int g[0];
	return 0;
}
