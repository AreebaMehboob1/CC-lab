// Function return type mismatch

#include <stdio.h>

int main()
{
	int a =4;
	char c = 'j';
	a=9;
	return 8.0;
}