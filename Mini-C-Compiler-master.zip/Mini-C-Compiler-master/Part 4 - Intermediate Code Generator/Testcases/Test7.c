// Invalid identifier name
#include <stdio.h>

int main()
{
	int a;
  	int !name;
	return 0;
}