// Function call before declaration
#include<stdio.h>

void main()
{
    int i,n;
    sum_func(i,n);  
}