// Strings and various types of comments
#include <stdio.h>

int b=10;

int main()
{
	int k=5;
	long int z;
	while(1){
		// Beginning of first infinite loop
		int k;
		while(1){
			/* Beginning of
			last 
			infinite loop
			*/
			printf("Hello World!");
		}
	}
	return 0;
}