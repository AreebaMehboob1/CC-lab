# Mini C Compiler
A Mini C Compiler Project designed using Lex and Yacc as part of course : Compiler Design Lab (CO351)

### Compiler Design contains 4 phases
1. [Lexical Analyzer](https://github.com/Shree987/Mini-C-Compiler/tree/master/Part%201%20-%20Lexical%20Analyzer)
2. [Syntax Analyzer](https://github.com/Shree987/Mini-C-Compiler/tree/master/Part%202%20-%20Syntax%20Analyzer)
3. [Semantic Analyzer](https://github.com/Shree987/Mini-C-Compiler/tree/master/Part%203%20-%20Semantic%20Analyzer)
4. [Intermediate Code Generator](https://github.com/Shree987/Mini-C-Compiler/tree/master/Part%204%20-Intermediate%20Code%20Generator)

### Team Members
* K Krishna Swaroop (181CO125)
* Shreeraksha R Aithal (181CO149)
* Swathi J S (181CO155)
* Yerramaddu Jahnavi (181CO260)
